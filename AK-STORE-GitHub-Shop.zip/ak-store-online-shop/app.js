import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";
import { getFirestore, collection, getDocs, query, where, orderBy } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";
import { firebaseConfig, WHATSAPP_NUMBER } from "./firebase-config.js";

const grid = document.querySelector("#product-grid");
const statusEl = document.querySelector("#status");
const searchInput = document.querySelector("#search");
const categoryFilter = document.querySelector("#category-filter");
const countEl = document.querySelector("#product-count");
document.querySelector("#year").textContent = new Date().getFullYear();

let allProducts = [];
const money = n => new Intl.NumberFormat("bn-BD", { maximumFractionDigits: 0 }).format(Number(n || 0));
const safe = value => String(value ?? "").replace(/[&<>"']/g, ch => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[ch]));
function showToast(message) {
  const toast = document.querySelector("#toast");
  toast.textContent = message; toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2600);
}
function renderProducts() {
  const term = searchInput.value.trim().toLocaleLowerCase("bn");
  const category = categoryFilter.value;
  const filtered = allProducts.filter(p =>
    (!category || p.category === category) &&
    (!term || `${p.name} ${p.category || ""} ${p.description || ""}`.toLocaleLowerCase("bn").includes(term))
  );
  countEl.textContent = `${money(filtered.length)}টি পণ্য`;
  grid.innerHTML = "";
  if (!filtered.length) {
    statusEl.hidden = false;
    statusEl.textContent = allProducts.length ? "এই খোঁজে কোনো পণ্য পাওয়া যায়নি।" : "এখনো কোনো পণ্য যোগ করা হয়নি।";
    return;
  }
  statusEl.hidden = true;
  for (const p of filtered) {
    const card = document.createElement("article");
    card.className = "product-card";
    const image = p.imageUrl ? `<img src="${safe(p.imageUrl)}" alt="${safe(p.name)}" loading="lazy">` : `<div class="image-placeholder">AK STORE</div>`;
    const details = [p.category, p.sizes ? `সাইজ: ${p.sizes}` : ""].filter(Boolean).join(" • ");
    const message = `আসসালামু আলাইকুম, AK STORE থেকে এই পণ্যটি অর্ডার করতে চাই:\nপণ্য: ${p.name}\nদাম: ৳${p.price}\n${p.sizes ? `সাইজ: ${p.sizes}\n` : ""}পণ্যের লিংক: ${location.origin}${location.pathname}#products`;
    const wa = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
    card.innerHTML = `${image}<div class="product-info"><span class="product-category">${safe(p.category || "AK STORE")}</span><h3>${safe(p.name)}</h3><p class="product-meta">${safe(details || "নতুন কালেকশন")}</p>${p.description ? `<p class="product-description">${safe(p.description)}</p>` : ""}<div class="product-bottom"><strong class="price">৳${money(p.price)}</strong><a class="order-btn" href="${wa}" target="_blank" rel="noopener noreferrer">WhatsApp-এ অর্ডার</a></div></div>`;
    grid.appendChild(card);
  }
}
async function loadProducts() {
  try {
    const app = initializeApp(firebaseConfig);
    const db = getFirestore(app);
    const snap = await getDocs(query(collection(db, "products"), where("active", "==", true), orderBy("createdAt", "desc")));
    allProducts = snap.docs.map(d => ({ id: d.id, ...d.data() }));
    const categories = [...new Set(allProducts.map(p => p.category).filter(Boolean))].sort();
    categoryFilter.innerHTML = '<option value="">সব ক্যাটাগরি</option>' + categories.map(c => `<option value="${safe(c)}">${safe(c)}</option>`).join("");
    renderProducts();
  } catch (err) {
    console.error(err);
    statusEl.hidden = false;
    statusEl.textContent = "পণ্য লোড করা যায়নি। Firebase সেটআপ ও Firestore Security Rules পরীক্ষা করুন।";
    countEl.textContent = "লোড হয়নি";
  }
}
searchInput.addEventListener("input", renderProducts);
categoryFilter.addEventListener("change", renderProducts);
if (WHATSAPP_NUMBER === "8801XXXXXXXXX" || !/^8801\d{9}$/.test(WHATSAPP_NUMBER)) {
  showToast("সেটআপের আগে firebase-config.js ফাইলে আপনার WhatsApp নম্বর বসান।");
}
loadProducts();
