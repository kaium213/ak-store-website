// Firebase Console থেকে আপনার প্রজেক্টের Web App config এখানে বসান।
// এই ফাইল GitHub Pages-এ প্রকাশিত হবে—এখানে কখনো private key বা service-account key রাখবেন না.
export const firebaseConfig = {
  apiKey: "PASTE_YOUR_FIREBASE_API_KEY",
  authDomain: "PASTE_YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_YOUR_PROJECT_ID",
  storageBucket: "PASTE_YOUR_STORAGE_BUCKET",
  messagingSenderId: "PASTE_YOUR_MESSAGING_SENDER_ID",
  appId: "PASTE_YOUR_FIREBASE_APP_ID"
};

// আপনার WhatsApp নম্বর আন্তর্জাতিক ফরম্যাটে, + বা স্পেস ছাড়া লিখুন।
// বাংলাদেশি উদাহরণ: 8801XXXXXXXXX — নিজের আসল নম্বর দিয়ে বদলাবেন।
export const WHATSAPP_NUMBER = "8801XXXXXXXXX";
