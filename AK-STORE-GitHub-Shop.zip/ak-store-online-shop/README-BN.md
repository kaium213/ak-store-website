# AK STORE — GitHub Pages + Firebase

এই প্রজেক্টে পাবলিক অনলাইন শপ, Firebase-চালিত Admin Panel এবং WhatsApp অর্ডার রয়েছে। নতুন পণ্য যোগ করতে ওয়েবসাইটের কোড বদলাতে হবে না; `admin.html`-এ লগইন করে পণ্যের তথ্য ও ছবি যোগ করবেন।

## কী কী লাগবে
- একটি GitHub অ্যাকাউন্ট
- একটি Google/Firebase অ্যাকাউন্ট
- আপনার দোকানের WhatsApp নম্বর

## ধাপ ১: Firebase প্রজেক্ট বানান
1. https://console.firebase.google.com/ খুলে **Create a project** চাপুন।
2. প্রজেক্ট তৈরি হলে Project Overview-তে Web `</>` আইকন চাপুন, অ্যাপের নাম দিন `AK STORE`, তারপর Register app করুন।
3. দেখানো Firebase config কপি করে এই রিপোজিটরির `firebase-config.js` ফাইলে বসান। `PASTE_...` লেখা প্রতিটি মান বদলাবেন।
4. একই ফাইলে `WHATSAPP_NUMBER`-এ আপনার নম্বর দিন। বাংলাদেশি নম্বরের উদাহরণ: `8801XXXXXXXXX`—নিজের নম্বরের ০ বাদ দিয়ে শুরুতে ৮৮ যোগ করে লিখুন। `+`, স্পেস বা ড্যাশ দেবেন না।

## ধাপ ২: Authentication চালু ও অ্যাডমিন তৈরি
1. Firebase Console → **Authentication** → **Get started** → **Sign-in method** → **Email/Password** চালু করুন।
2. Authentication → **Users** → **Add user** দিয়ে আপনার নিজের অ্যাডমিন ইমেইল ও শক্তিশালী পাসওয়ার্ড তৈরি করুন।
3. তৈরি হওয়া ইউজারের **UID** কপি করুন।
4. `firestore.rules` এবং `storage.rules`—দুই ফাইলেই `REPLACE_WITH_ADMIN_UID`-এর জায়গায় ওই একই UID বসান।
5. Authentication-এর সেটিংসে **Allow users to create accounts / sign-up** চালু করবেন না। এই সাইটে পাবলিক রেজিস্ট্রেশন ফর্ম নেই; অ্যাডমিন Firebase Console থেকে তৈরি করবেন।

## ধাপ ৩: Firestore Database তৈরি
1. Firebase Console → **Firestore Database** → **Create database**।
2. Production mode বেছে নিন এবং আপনার উপযুক্ত region নির্বাচন করুন।
3. Firestore → **Rules**-এ গিয়ে এই রিপোজিটরির `firestore.rules` ফাইলের পুরো লেখা বসিয়ে **Publish** করুন।
4. `products` নামে collection হাতে তৈরি করার দরকার নেই। অ্যাডমিন প্যানেল থেকে প্রথম পণ্য সেভ করলে এটি তৈরি হবে।

## ধাপ ৪: ছবি আপলোডের জন্য Storage
1. Firebase Console → **Storage** → **Get started**। যদি Firebase প্ল্যান/বিলিং সেটআপ চাই, Firebase-এর বর্তমান নির্দেশনা অনুসরণ করুন।
2. Storage → **Rules**-এ `storage.rules` ফাইলের পুরো লেখা বসিয়ে **Publish** করুন।
3. Firebase Console-এর Project settings-এ `storageBucket` মানটি `firebase-config.js`-এ ঠিক আছে কি না দেখুন।

## ধাপ ৫: GitHub-এ আপলোড
1. GitHub-এ নতুন repository বানান, যেমন `ak-store`.
2. এই ZIP-এর ফাইলগুলো Extract করে repository-এর **root**-এ আপলোড করুন। ZIP ফাইলটিকেই একমাত্র ফাইল হিসেবে আপলোড করবেন না।
3. GitHub repository → **Settings** → **Pages**।
4. **Build and deployment**-এ Source হিসেবে **Deploy from a branch** বেছে নিন; branch `main`, folder `/(root)` নির্বাচন করে Save চাপুন।
5. প্রকাশ হতে কয়েক মিনিট লাগতে পারে। Pages-এ দেখানো সাইটের URL খুলুন। Admin Panel-এর URL হবে `https://আপনার-ইউজারনেম.github.io/ak-store/admin.html` (নিজের URL ব্যবহার করুন)।

## ধাপ ৬: প্রথম পণ্য যোগ করুন
1. সাইটের `admin.html` পেজ খুলুন।
2. Firebase Authentication-এ তৈরি করা ইমেইল ও পাসওয়ার্ড দিয়ে লগইন করুন।
3. পণ্যের নাম, দাম, ক্যাটাগরি, সাইজ, বিবরণ ও ছবি দিন।
4. **পণ্য সংরক্ষণ করুন** চাপুন। পরে একই পণ্যের পাশে **এডিট** বা **মুছুন** ব্যবহার করতে পারবেন।
5. ওয়েবসাইটের মূল পেজে পণ্য দেখা যাবে। ক্রেতা **WhatsApp-এ অর্ডার** চাপলে আপনার নম্বরে প্রি-ফিল করা বার্তা খুলবে।

## গুরুত্বপূর্ণ নিরাপত্তা
- `firebase-config.js`-এর Firebase web config সাধারণত ওয়েব অ্যাপে ব্যবহারের জন্য প্রকাশ্য; কিন্তু Firebase Security Rules-ই ডেটার নিরাপত্তা নিশ্চিত করে। UID বসানো ও Rules Publish না করে সাইট প্রকাশ করবেন না।
- কখনো Firebase service-account JSON, private key বা অ্যাডমিন পাসওয়ার্ড GitHub-এ আপলোড করবেন না।
- অ্যাডমিন UID ভুল হলে পণ্য যোগ/পরিবর্তন করতে permission error আসবে। দুই Rules ফাইলে একই UID আছে কি না দেখুন।
- `storage.rules`-এ ছবি আপলোড 5 MB-এর নিচে এবং image MIME type-এ সীমিত।
- GitHub Pages হলো static hosting। Firebase/WhatsApp ছাড়া এখানে নিজে থেকে নিরাপদ লগইন বা ডেটাবেস থাকে না।
- `firebase-config.js` পরিবর্তন করলে GitHub-এ সেই পরিবর্তন Commit করতে হবে।

## সমস্যা হলে
- **পণ্য লোড হয় না:** Firebase config, Firestore তৈরি এবং Rules পরীক্ষা করুন।
- **লগইন হয় না:** Email/Password provider চালু আছে কি না এবং ইউজার তৈরি হয়েছে কি না দেখুন।
- **পণ্য সেভ হয় না:** দুই Rules ফাইলে সঠিক UID, Storage চালু এবং config পরীক্ষা করুন।
- **WhatsApp নম্বর ভুল:** `firebase-config.js`-এ `WHATSAPP_NUMBER` বদলে Commit করুন।
- **পণ্য সেভ হয়েছে কিন্তু দেখা যাচ্ছে না:** পণ্যের “ওয়েবসাইটে পণ্যটি দেখান” চেক করা আছে কি না দেখুন।

> এটি একটি শুরু করার উপযোগী দোকান-টেমপ্লেট। অনলাইন পেমেন্ট, কুরিয়ার ইন্টিগ্রেশন, স্টক হিসাব ও অর্ডার ম্যানেজমেন্ট আলাদাভাবে যোগ করতে হবে।
