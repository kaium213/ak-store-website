import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";
import { getFirestore, collection, getDocs, addDoc, updateDoc, deleteDoc, doc, serverTimestamp, query, orderBy } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";
import { getStorage, ref, uploadBytes, getDownloadURL, deleteObject } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-storage.js";
import { firebaseConfig } from "./firebase-config.js";

const loginPanel = document.querySelector("#login-panel");
const dashboard = document.querySelector("#dashboard");
const loginMessage = document.querySelector("#login-message");
const productMessage = document.querySelector("#product-message");
const productForm = document.querySelector("#product-form");
const list = document.querySelector("#admin-products");
const saveBtn = document.querySelector("#save-product-btn");
let app, auth, db, storage, currentUser, editingId = null, editingImagePath = "";

function toast(message) {
  const el = document.querySelector("#toast"); el.textContent = message; el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2600);
}
function setMessage(el, message, isError = false) {
  el.textContent = message; el.classList.toggle("error", isError);
}
function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[ch]));
}
function setLoggedIn(user) {
  currentUser = user;
  loginPanel.hidden = !!user; dashboard.hidden = !user;
  if (user) {
    document.querySelector("#signed-in-as").textContent = `লগইন: ${user.email}`;
    loadAdminProducts();
  }
}
try {
  app = initializeApp(firebaseConfig);
  auth = getAuth(app); db = getFirestore(app); storage = getStorage(app);
  onAuthStateChanged(auth, setLoggedIn);
} catch (e) {
  setMessage(loginMessage, "Firebase কনফিগারেশন ঠিক নেই। firebase-config.js ফাইলটি দেখুন।", true);
}

document.querySelector("#login-form").addEventListener("submit", async e => {
  e.preventDefault(); setMessage(loginMessage, "লগইন হচ্ছে…");
  try {
    await signInWithEmailAndPassword(auth, document.querySelector("#login-email").value.trim(), document.querySelector("#login-password").value);
    setMessage(loginMessage, "");
  } catch (err) {
    console.error(err); setMessage(loginMessage, "লগইন হয়নি। ইমেইল, পাসওয়ার্ড ও Firebase Authentication সেটিংস পরীক্ষা করুন।", true);
  }
});
document.querySelector("#logout-btn").addEventListener("click", async () => { await signOut(auth); resetForm(); });
document.querySelector("#refresh-btn").addEventListener("click", loadAdminProducts);
document.querySelector("#cancel-edit-btn").addEventListener("click", resetForm);

function resetForm() {
  editingId = null; editingImagePath = ""; productForm.reset();
  document.querySelector("#p-active").checked = true;
  document.querySelector("#product-form-title").textContent = "নতুন পণ্য যোগ করুন";
  saveBtn.textContent = "পণ্য সংরক্ষণ করুন";
  document.querySelector("#cancel-edit-btn").hidden = true;
  setMessage(productMessage, "");
}
productForm.addEventListener("submit", async e => {
  e.preventDefault();
  if (!currentUser) return setMessage(productMessage, "আগে অ্যাডমিন লগইন করুন।", true);
  const name = document.querySelector("#p-name").value.trim();
  const price = Number(document.querySelector("#p-price").value);
  const imageFile = document.querySelector("#p-image").files[0];
  if (!name || !Number.isFinite(price) || price < 0) return setMessage(productMessage, "পণ্যের নাম ও সঠিক দাম দিন।", true);
  if (!editingId && !imageFile) return setMessage(productMessage, "নতুন পণ্যের জন্য একটি ছবি দিন।", true);
  saveBtn.disabled = true; setMessage(productMessage, "পণ্য সংরক্ষণ হচ্ছে…");
  try {
    let imageUrl = document.querySelector("#p-image").dataset.currentUrl || "";
    let imagePath = editingImagePath;
    if (imageFile) {
      if (!imageFile.type.startsWith("image/")) throw new Error("ছবির ফাইল নির্বাচন করুন।");
      if (imageFile.size > 5 * 1024 * 1024) throw new Error("ছবির সাইজ 5 MB-এর কম হতে হবে।");
      const safeName = imageFile.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      imagePath = `products/${Date.now()}_${safeName}`;
      const storageRef = ref(storage, imagePath);
      await uploadBytes(storageRef, imageFile, { contentType: imageFile.type });
      imageUrl = await getDownloadURL(storageRef);
    }
    const data = {
      name, price,
      category: document.querySelector("#p-category").value.trim(),
      sizes: document.querySelector("#p-sizes").value.trim(),
      description: document.querySelector("#p-description").value.trim(),
      imageUrl, imagePath,
      active: document.querySelector("#p-active").checked,
      updatedAt: serverTimestamp()
    };
    if (editingId) {
      await updateDoc(doc(db, "products", editingId), data);
      if (imageFile && editingImagePath && editingImagePath !== imagePath) {
        try { await deleteObject(ref(storage, editingImagePath)); } catch (e) { console.warn("Old image cleanup failed", e); }
      }
    } else {
      data.createdAt = serverTimestamp();
      await addDoc(collection(db, "products"), data);
    }
    resetForm(); await loadAdminProducts(); toast("পণ্য সফলভাবে সংরক্ষণ হয়েছে।");
  } catch (err) {
    console.error(err);
    setMessage(productMessage, err.message || "সংরক্ষণ করা যায়নি। Firebase Rules ও কনফিগারেশন পরীক্ষা করুন।", true);
  } finally { saveBtn.disabled = false; }
});

async function loadAdminProducts() {
  if (!currentUser) return;
  list.innerHTML = "<p class='muted'>পণ্য লোড হচ্ছে…</p>";
  try {
    const snap = await getDocs(query(collection(db, "products"), orderBy("createdAt", "desc")));
    if (snap.empty) { list.innerHTML = "<p class='muted'>এখনো কোনো পণ্য যোগ করা হয়নি।</p>"; return; }
    list.innerHTML = "";
    snap.docs.forEach(d => {
      const p = d.data();
      const row = document.createElement("article"); row.className = "admin-product";
      row.innerHTML = `${p.imageUrl ? `<img src="${esc(p.imageUrl)}" alt="">` : `<div class="mini-placeholder">AK</div>`}<div class="admin-product-details"><strong>${esc(p.name)}</strong><span>৳${new Intl.NumberFormat("bn-BD").format(Number(p.price || 0))} · ${esc(p.category || "ক্যাটাগরি নেই")}</span><small>${p.active ? "ওয়েবসাইটে দেখানো হচ্ছে" : "লুকানো আছে"}</small></div><div class="admin-actions"><button class="secondary-btn edit-btn" type="button">এডিট</button><button class="danger-btn delete-btn" type="button">মুছুন</button></div>`;
      row.querySelector(".edit-btn").addEventListener("click", () => startEdit(d.id, p));
      row.querySelector(".delete-btn").addEventListener("click", () => removeProduct(d.id, p));
      list.appendChild(row);
    });
  } catch (err) {
    console.error(err); list.innerHTML = "<p class='form-message error'>পণ্য লোড হয়নি। Security Rules ও Firebase সেটআপ পরীক্ষা করুন।</p>";
  }
}
function startEdit(id, p) {
  editingId = id; editingImagePath = p.imagePath || "";
  document.querySelector("#p-name").value = p.name || "";
  document.querySelector("#p-price").value = p.price ?? "";
  document.querySelector("#p-category").value = p.category || "";
  document.querySelector("#p-sizes").value = p.sizes || "";
  document.querySelector("#p-description").value = p.description || "";
  document.querySelector("#p-active").checked = p.active !== false;
  document.querySelector("#p-image").value = "";
  document.querySelector("#p-image").dataset.currentUrl = p.imageUrl || "";
  document.querySelector("#product-form-title").textContent = "পণ্য পরিবর্তন করুন";
  saveBtn.textContent = "পরিবর্তন সংরক্ষণ করুন";
  document.querySelector("#cancel-edit-btn").hidden = false;
  setMessage(productMessage, "পণ্যের তথ্য পরিবর্তন করুন। নতুন ছবি না দিলেও আগের ছবি থাকবে।");
  window.scrollTo({ top: 0, behavior: "smooth" });
}
async function removeProduct(id, p) {
  if (!confirm(`“${p.name}” পণ্যটি মুছে ফেলবেন?`)) return;
  try {
    await deleteDoc(doc(db, "products", id));
    if (p.imagePath) { try { await deleteObject(ref(storage, p.imagePath)); } catch (e) { console.warn(e); } }
    await loadAdminProducts(); toast("পণ্য মুছে ফেলা হয়েছে।");
  } catch (err) {
    console.error(err); toast("পণ্য মুছতে সমস্যা হয়েছে। Rules পরীক্ষা করুন।");
  }
}
